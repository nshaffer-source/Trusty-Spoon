﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Birdo : MonoBehaviour
{
    private Vector3 _initialPosition; //definitions
    private bool _birdWasLaunched;
    private float _timeSittingAround;

    [SerializeField] private float _launchPower = 500;

   private void Awake()
    {
        _initialPosition = transform.position;
    }

    private void Update()
    {
        GetComponent<LineRenderer>().SetPosition(1, _initialPosition);
        GetComponent<LineRenderer>().SetPosition(0, transform.position);

        if (_birdWasLaunched &&
            GetComponent<Rigidbody2D>().velocity.magnitude <= 0.1 ) //if the bird is motionless then it will reset
        {
            _timeSittingAround += Time.deltaTime;
        }

        if (transform.position.y > 10 || //the boundries in terms of when it resets the birds position
            transform.position.y < -10 ||
            transform.position.x > 10 ||
            transform.position.x < -12 ||
            _timeSittingAround > 3)
        {
            string currentSceneName = SceneManager.GetActiveScene().name; //resets the scene for either of these reassons
            SceneManager.LoadScene(currentSceneName);
        }

    }

   private void OnMouseDown()
    {
        GetComponent<SpriteRenderer>().color = Color.blue; //whats changes when the bird is clicked on

        GetComponent<LineRenderer>().enabled = true;
    }

   private void OnMouseUp()
   {
        GetComponent<SpriteRenderer>().color = Color.white; //what happens when mouse click is released

        Vector2 directionToinitialPosition = _initialPosition - transform.position; // calculating the diffirence in position and distance from before to after the click
        
        GetComponent<Rigidbody2D>().AddForce(directionToinitialPosition * _launchPower);
        GetComponent<Rigidbody2D>().gravityScale = 1;
        _birdWasLaunched = true;

        GetComponent<LineRenderer>().enabled = false;
    }

   private void OnMouseDrag()
   {
        Vector3 newPosition = Camera.main.ScreenToWorldPoint(Input.mousePosition); //calculates postions based on where the bird is dragged
        transform.position = new Vector3 (newPosition.x, newPosition.y);
   }

}
